$(document).ready(() =>{
    listServices = $("#list-services");
    
    chosenList = $("#chosen-list");
    lengthChosen = $("#length-list")
    lengthChosen.hide();
    cart = $(".btn-dark");
    cart.hide();
    $.ajax({
        method: 'GET',
        url : "assets/scripts/data.json",
        datatype: 'json'
    }).done(function(data){
        renderServices(data);
    }).fail(function(){
        console.log("No hay datos");
    });

});

console.log("Tu puedes Mariano!");


$("#empty-chosen").click(function() { 
    chosenList.empty();
    lengthChosen.hide();
    cart.hide();
    chosen = [];
    chosen.length = 0;
    localStorage.clear();
});